
# المدرسة السادسة والعشرون بتبوك — تقارير الأنشطة (GitHub Pages)

## النشر على GitHub Pages
1) ارفع الملفات إلى جذر المستودع (`index.html`, `assets/26.png`, `.nojekyll`).
2) من **Settings → Pages**: اختر **Deploy from a branch**، ثم **Branch: main** و**Folder: /(root)**، ثم **Save**.
3) افتح رابط: `https://USERNAME.github.io/REPO/`.

> ملاحظات:
> - ملف `.nojekyll` يعطّل Jekyll ويمنع تجاهل مجلدات تبدأ بـ`_` (احتياطي).
> - غيّر صورة الشعار بوضع شعارك كملف `assets/26.png`.

